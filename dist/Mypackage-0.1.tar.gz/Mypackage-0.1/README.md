# Mypackage
this library was created as an example of how publish our own python package
